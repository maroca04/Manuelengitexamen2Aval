#! /bin/bash
echo "dime tu nombre"
read nombre

echo "dime tu apellido"
read apellido

sleep 5.0

echo "Tu nombre completo es $nombre $apellido"