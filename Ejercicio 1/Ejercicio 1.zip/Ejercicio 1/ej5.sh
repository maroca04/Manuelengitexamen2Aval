#!/bin/bash


#PREGUNTAR A VICENT


read -p "Dime el titulo del libro a ingresar" titulo

read -p "Dime el año del libro a ingresar" anno

if [[ "$anno" =~ ^[0-9]+$ ]]

 then
    echo "Error: El año debe ser un número entero."
    exit

$generos = ciencia, terror, infantil.

echo "¿que genero quieres?"
read genero


